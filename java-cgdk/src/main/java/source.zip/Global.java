import model.Car;
import model.Game;
import model.Move;
import model.World;
import java.util.*;

public final class Global{

	public static Wave s_wave = null;
	public static VisualClient s_vc = null;
	public static final boolean DBG_RNDR = false;
}
